let btn=document.querySelector("button")
let form=document.querySelector("form")
form.addEventListener ("click",(e)=>{
    e.preventDefault()
    let ename =document.getElementById("ename").value 
    let pass = document.getElementById("pass").value 
    console.log(ename,pass)
   
   var confirmusername=sessionStorage.getItem("empname",ename)
   var confirmuserpassword=sessionStorage.getItem("password",pass)
   if(ename ==""&&pass==""){
    alert("both empty")
   }
   else if (ename ==""||pass=="")
   {
    if (ename =="")alert("name  field cannot be empty")
     if(pass=="")alert("password field cannot be empty")
   }
   else if (ename == confirmusername&&pass== confirmuserpassword)
   window.open("./home.html")
   else if (ename !== confirmusername||pass== confirmuserpassword)
   alert("username is not matching")
   else if (ename == confirmusername||pass!== confirmuserpassword)
   alert("passwordis not matching")
   
   
   
})
