let btn=document.querySelector("button")

btn.addEventListener ("click",(e)=>{
    e.preventDefault()
    let ename =document.getElementById("ename").value 
    let pass = document.getElementById("pass").value 
    console.log(ename,pass)
   // localStorage.setItem("firstname",fname)
   // localStorage.setItem("password",pass)
    sessionStorage.setItem("empname",ename)
    sessionStorage.setItem("password",pass)


    if(ename !=="" &&pass!==""){
        window.open("./login.html")
    }else if (ename =="" &&pass==""){
        alert(" Enter the credentials")
    }
})